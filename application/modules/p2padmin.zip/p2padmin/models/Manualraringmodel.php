<?php
class Manualraringmodel extends CI_Model{

    public function __construct()
    {
        parent::__construct();
    }

    public function maunalRating()
    {

    }
}
?>